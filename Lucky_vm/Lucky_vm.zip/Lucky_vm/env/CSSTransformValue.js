// CSSTransformValue 对象 
CSSTransformValue = function CSSTransformValue(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'CSSTransformValue': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(CSSTransformValue,"CSSTransformValue");
Object.setPrototypeOf(CSSTransformValue.prototype, CSSStyleValue.prototype);
framevm.toolsFunc.defineProperty(CSSTransformValue.prototype, "entries", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSTransformValue.prototype, "CSSTransformValue", "entries", arguments)}});
framevm.toolsFunc.defineProperty(CSSTransformValue.prototype, "keys", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSTransformValue.prototype, "CSSTransformValue", "keys", arguments)}});
framevm.toolsFunc.defineProperty(CSSTransformValue.prototype, "values", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSTransformValue.prototype, "CSSTransformValue", "values", arguments)}});
framevm.toolsFunc.defineProperty(CSSTransformValue.prototype, "forEach", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSTransformValue.prototype, "CSSTransformValue", "forEach", arguments)}});
framevm.toolsFunc.defineProperty(CSSTransformValue.prototype, "length", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSTransformValue.prototype, "CSSTransformValue", "length_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(CSSTransformValue.prototype, "is2D", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSTransformValue.prototype, "CSSTransformValue", "is2D_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(CSSTransformValue.prototype, "toMatrix", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSTransformValue.prototype, "CSSTransformValue", "toMatrix", arguments)}});
