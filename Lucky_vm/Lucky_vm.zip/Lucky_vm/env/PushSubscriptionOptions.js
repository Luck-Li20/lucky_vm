// PushSubscriptionOptions 对象 
PushSubscriptionOptions = function PushSubscriptionOptions(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(PushSubscriptionOptions,"PushSubscriptionOptions");
framevm.toolsFunc.defineProperty(PushSubscriptionOptions.prototype, "userVisibleOnly", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, PushSubscriptionOptions.prototype, "PushSubscriptionOptions", "userVisibleOnly_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(PushSubscriptionOptions.prototype, "applicationServerKey", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, PushSubscriptionOptions.prototype, "PushSubscriptionOptions", "applicationServerKey_get", arguments)}, set:undefined});
