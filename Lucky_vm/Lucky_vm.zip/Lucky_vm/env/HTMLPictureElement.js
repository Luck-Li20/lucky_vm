// HTMLPictureElement 对象 
HTMLPictureElement = function HTMLPictureElement(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(HTMLPictureElement,"HTMLPictureElement");
Object.setPrototypeOf(HTMLPictureElement.prototype, HTMLElement.prototype);
