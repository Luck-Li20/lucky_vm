// BluetoothUUID 对象 
BluetoothUUID = function BluetoothUUID(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(BluetoothUUID,"BluetoothUUID");
framevm.toolsFunc.defineProperty(BluetoothUUID, "canonicalUUID", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, BluetoothUUID, "BluetoothUUID", "canonicalUUID", arguments)}});
framevm.toolsFunc.defineProperty(BluetoothUUID, "getCharacteristic", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, BluetoothUUID, "BluetoothUUID", "getCharacteristic", arguments)}});
framevm.toolsFunc.defineProperty(BluetoothUUID, "getDescriptor", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, BluetoothUUID, "BluetoothUUID", "getDescriptor", arguments)}});
framevm.toolsFunc.defineProperty(BluetoothUUID, "getService", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, BluetoothUUID, "BluetoothUUID", "getService", arguments)}});
