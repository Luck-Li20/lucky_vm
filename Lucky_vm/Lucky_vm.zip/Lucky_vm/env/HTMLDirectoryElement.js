// HTMLDirectoryElement 对象 
HTMLDirectoryElement = function HTMLDirectoryElement(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(HTMLDirectoryElement,"HTMLDirectoryElement");
Object.setPrototypeOf(HTMLDirectoryElement.prototype, HTMLElement.prototype);
framevm.toolsFunc.defineProperty(HTMLDirectoryElement.prototype, "compact", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLDirectoryElement.prototype, "HTMLDirectoryElement", "compact_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLDirectoryElement.prototype, "HTMLDirectoryElement", "compact_set", arguments)}});
