// NavigatorUAData 对象 
NavigatorUAData = function NavigatorUAData(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(NavigatorUAData,"NavigatorUAData");
framevm.toolsFunc.defineProperty(NavigatorUAData.prototype, "brands", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, NavigatorUAData.prototype, "NavigatorUAData", "brands_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(NavigatorUAData.prototype, "mobile", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, NavigatorUAData.prototype, "NavigatorUAData", "mobile_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(NavigatorUAData.prototype, "platform", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, NavigatorUAData.prototype, "NavigatorUAData", "platform_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(NavigatorUAData.prototype, "getHighEntropyValues", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, NavigatorUAData.prototype, "NavigatorUAData", "getHighEntropyValues", arguments)}});
framevm.toolsFunc.defineProperty(NavigatorUAData.prototype, "toJSON", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, NavigatorUAData.prototype, "NavigatorUAData", "toJSON", arguments)}});
