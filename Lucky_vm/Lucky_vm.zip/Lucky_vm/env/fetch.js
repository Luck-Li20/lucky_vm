//  对象 
 = function (){};
framevm.toolsFunc.safeProto(,"");
