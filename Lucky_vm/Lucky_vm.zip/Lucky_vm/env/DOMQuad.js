// DOMQuad 对象 
DOMQuad = function DOMQuad(){};
framevm.toolsFunc.safeProto(DOMQuad,"DOMQuad");
framevm.toolsFunc.defineProperty(DOMQuad, "fromQuad", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, DOMQuad, "DOMQuad", "fromQuad", arguments)}});
framevm.toolsFunc.defineProperty(DOMQuad, "fromRect", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, DOMQuad, "DOMQuad", "fromRect", arguments)}});
framevm.toolsFunc.defineProperty(DOMQuad.prototype, "p1", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DOMQuad.prototype, "DOMQuad", "p1_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DOMQuad.prototype, "p2", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DOMQuad.prototype, "DOMQuad", "p2_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DOMQuad.prototype, "p3", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DOMQuad.prototype, "DOMQuad", "p3_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DOMQuad.prototype, "p4", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DOMQuad.prototype, "DOMQuad", "p4_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DOMQuad.prototype, "getBounds", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, DOMQuad.prototype, "DOMQuad", "getBounds", arguments)}});
framevm.toolsFunc.defineProperty(DOMQuad.prototype, "toJSON", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, DOMQuad.prototype, "DOMQuad", "toJSON", arguments)}});
