// FragmentDirective 对象 
FragmentDirective = function FragmentDirective(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(FragmentDirective,"FragmentDirective");
