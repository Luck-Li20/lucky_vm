// Cache 对象 
Cache = function Cache(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(Cache,"Cache");
framevm.toolsFunc.defineProperty(Cache.prototype, "add", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Cache.prototype, "Cache", "add", arguments)}});
framevm.toolsFunc.defineProperty(Cache.prototype, "addAll", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Cache.prototype, "Cache", "addAll", arguments)}});
framevm.toolsFunc.defineProperty(Cache.prototype, "delete", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Cache.prototype, "Cache", "delete", arguments)}});
framevm.toolsFunc.defineProperty(Cache.prototype, "keys", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Cache.prototype, "Cache", "keys", arguments)}});
framevm.toolsFunc.defineProperty(Cache.prototype, "match", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Cache.prototype, "Cache", "match", arguments)}});
framevm.toolsFunc.defineProperty(Cache.prototype, "matchAll", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Cache.prototype, "Cache", "matchAll", arguments)}});
framevm.toolsFunc.defineProperty(Cache.prototype, "put", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Cache.prototype, "Cache", "put", arguments)}});
