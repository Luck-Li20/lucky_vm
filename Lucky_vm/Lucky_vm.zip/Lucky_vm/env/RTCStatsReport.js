// RTCStatsReport 对象 
RTCStatsReport = function RTCStatsReport(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(RTCStatsReport,"RTCStatsReport");
framevm.toolsFunc.defineProperty(RTCStatsReport.prototype, "size", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, RTCStatsReport.prototype, "RTCStatsReport", "size_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(RTCStatsReport.prototype, "entries", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, RTCStatsReport.prototype, "RTCStatsReport", "entries", arguments)}});
framevm.toolsFunc.defineProperty(RTCStatsReport.prototype, "forEach", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, RTCStatsReport.prototype, "RTCStatsReport", "forEach", arguments)}});
framevm.toolsFunc.defineProperty(RTCStatsReport.prototype, "get", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, RTCStatsReport.prototype, "RTCStatsReport", "get", arguments)}});
framevm.toolsFunc.defineProperty(RTCStatsReport.prototype, "has", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, RTCStatsReport.prototype, "RTCStatsReport", "has", arguments)}});
framevm.toolsFunc.defineProperty(RTCStatsReport.prototype, "keys", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, RTCStatsReport.prototype, "RTCStatsReport", "keys", arguments)}});
framevm.toolsFunc.defineProperty(RTCStatsReport.prototype, "values", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, RTCStatsReport.prototype, "RTCStatsReport", "values", arguments)}});
