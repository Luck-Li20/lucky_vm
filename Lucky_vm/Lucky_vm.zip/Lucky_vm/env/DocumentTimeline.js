// DocumentTimeline 对象 
DocumentTimeline = function DocumentTimeline(){};
framevm.toolsFunc.safeProto(DocumentTimeline,"DocumentTimeline");
Object.setPrototypeOf(DocumentTimeline.prototype, AnimationTimeline.prototype);
