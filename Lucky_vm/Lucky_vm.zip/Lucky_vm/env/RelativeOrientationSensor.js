// RelativeOrientationSensor 对象 
RelativeOrientationSensor = function RelativeOrientationSensor(){};
framevm.toolsFunc.safeProto(RelativeOrientationSensor,"RelativeOrientationSensor");
Object.setPrototypeOf(RelativeOrientationSensor.prototype, OrientationSensor.prototype);
