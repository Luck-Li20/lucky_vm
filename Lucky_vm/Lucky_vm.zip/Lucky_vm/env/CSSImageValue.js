// CSSImageValue 对象 
CSSImageValue = function CSSImageValue(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CSSImageValue,"CSSImageValue");
Object.setPrototypeOf(CSSImageValue.prototype, CSSStyleValue.prototype);
