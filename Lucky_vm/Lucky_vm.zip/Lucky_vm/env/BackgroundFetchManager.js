// BackgroundFetchManager 对象 
BackgroundFetchManager = function BackgroundFetchManager(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(BackgroundFetchManager,"BackgroundFetchManager");
framevm.toolsFunc.defineProperty(BackgroundFetchManager.prototype, "fetch", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, BackgroundFetchManager.prototype, "BackgroundFetchManager", "fetch", arguments)}});
framevm.toolsFunc.defineProperty(BackgroundFetchManager.prototype, "get", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, BackgroundFetchManager.prototype, "BackgroundFetchManager", "get", arguments)}});
framevm.toolsFunc.defineProperty(BackgroundFetchManager.prototype, "getIds", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, BackgroundFetchManager.prototype, "BackgroundFetchManager", "getIds", arguments)}});
