// MediaCapabilities 对象
MediaCapabilities = function MediaCapabilities(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(MediaCapabilities,"MediaCapabilities");
framevm.toolsFunc.defineProperty(MediaCapabilities.prototype, "decodingInfo", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MediaCapabilities.prototype, "MediaCapabilities", "decodingInfo", arguments)}});
framevm.toolsFunc.defineProperty(MediaCapabilities.prototype, "encodingInfo", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MediaCapabilities.prototype, "MediaCapabilities", "encodingInfo", arguments)}});
