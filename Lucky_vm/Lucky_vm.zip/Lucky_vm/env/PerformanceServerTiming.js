// PerformanceServerTiming 对象 
PerformanceServerTiming = function PerformanceServerTiming(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(PerformanceServerTiming,"PerformanceServerTiming");
framevm.toolsFunc.defineProperty(PerformanceServerTiming.prototype, "name", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, PerformanceServerTiming.prototype, "PerformanceServerTiming", "name_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(PerformanceServerTiming.prototype, "duration", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, PerformanceServerTiming.prototype, "PerformanceServerTiming", "duration_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(PerformanceServerTiming.prototype, "description", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, PerformanceServerTiming.prototype, "PerformanceServerTiming", "description_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(PerformanceServerTiming.prototype, "toJSON", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, PerformanceServerTiming.prototype, "PerformanceServerTiming", "toJSON", arguments)}});
