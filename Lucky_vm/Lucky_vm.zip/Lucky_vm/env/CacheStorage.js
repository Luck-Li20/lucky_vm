// CacheStorage 对象 
CacheStorage = function CacheStorage(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CacheStorage,"CacheStorage");
framevm.toolsFunc.defineProperty(CacheStorage.prototype, "delete", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CacheStorage.prototype, "CacheStorage", "delete", arguments)}});
framevm.toolsFunc.defineProperty(CacheStorage.prototype, "has", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CacheStorage.prototype, "CacheStorage", "has", arguments)}});
framevm.toolsFunc.defineProperty(CacheStorage.prototype, "keys", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CacheStorage.prototype, "CacheStorage", "keys", arguments)}});
framevm.toolsFunc.defineProperty(CacheStorage.prototype, "match", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CacheStorage.prototype, "CacheStorage", "match", arguments)}});
framevm.toolsFunc.defineProperty(CacheStorage.prototype, "open", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CacheStorage.prototype, "CacheStorage", "open", arguments)}});
