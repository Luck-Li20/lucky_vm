// AnimationEffect 对象 
AnimationEffect = function AnimationEffect(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(AnimationEffect,"AnimationEffect");
framevm.toolsFunc.defineProperty(AnimationEffect.prototype, "getComputedTiming", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, AnimationEffect.prototype, "AnimationEffect", "getComputedTiming", arguments)}});
framevm.toolsFunc.defineProperty(AnimationEffect.prototype, "getTiming", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, AnimationEffect.prototype, "AnimationEffect", "getTiming", arguments)}});
framevm.toolsFunc.defineProperty(AnimationEffect.prototype, "updateTiming", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, AnimationEffect.prototype, "AnimationEffect", "updateTiming", arguments)}});
