// LinearAccelerationSensor 对象 
LinearAccelerationSensor = function LinearAccelerationSensor(){};
framevm.toolsFunc.safeProto(LinearAccelerationSensor,"LinearAccelerationSensor");
Object.setPrototypeOf(LinearAccelerationSensor.prototype, Accelerometer.prototype);
