// FormData 对象 
FormData = function FormData(){};
framevm.toolsFunc.safeProto(FormData,"FormData");
framevm.toolsFunc.defineProperty(FormData.prototype, "append", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FormData.prototype, "FormData", "append", arguments)}});
framevm.toolsFunc.defineProperty(FormData.prototype, "delete", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FormData.prototype, "FormData", "delete", arguments)}});
framevm.toolsFunc.defineProperty(FormData.prototype, "get", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FormData.prototype, "FormData", "get", arguments)}});
framevm.toolsFunc.defineProperty(FormData.prototype, "getAll", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FormData.prototype, "FormData", "getAll", arguments)}});
framevm.toolsFunc.defineProperty(FormData.prototype, "has", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FormData.prototype, "FormData", "has", arguments)}});
framevm.toolsFunc.defineProperty(FormData.prototype, "set", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FormData.prototype, "FormData", "set", arguments)}});
framevm.toolsFunc.defineProperty(FormData.prototype, "entries", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FormData.prototype, "FormData", "entries", arguments)}});
framevm.toolsFunc.defineProperty(FormData.prototype, "forEach", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FormData.prototype, "FormData", "forEach", arguments)}});
framevm.toolsFunc.defineProperty(FormData.prototype, "keys", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FormData.prototype, "FormData", "keys", arguments)}});
framevm.toolsFunc.defineProperty(FormData.prototype, "values", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FormData.prototype, "FormData", "values", arguments)}});
