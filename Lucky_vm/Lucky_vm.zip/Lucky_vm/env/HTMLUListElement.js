// HTMLUListElement 对象
HTMLUListElement = function HTMLUListElement(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(HTMLUListElement,"HTMLUListElement");
Object.setPrototypeOf(HTMLUListElement.prototype, HTMLElement.prototype);
framevm.toolsFunc.defineProperty(HTMLUListElement.prototype, "compact", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLUListElement.prototype, "HTMLUListElement", "compact_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLUListElement.prototype, "HTMLUListElement", "compact_set", arguments)}});
framevm.toolsFunc.defineProperty(HTMLUListElement.prototype, "type", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLUListElement.prototype, "HTMLUListElement", "type_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLUListElement.prototype, "HTMLUListElement", "type_set", arguments)}});
