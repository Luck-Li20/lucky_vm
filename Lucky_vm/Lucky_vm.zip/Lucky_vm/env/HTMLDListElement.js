// HTMLDListElement 对象 
HTMLDListElement = function HTMLDListElement(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(HTMLDListElement,"HTMLDListElement");
Object.setPrototypeOf(HTMLDListElement.prototype, HTMLElement.prototype);
framevm.toolsFunc.defineProperty(HTMLDListElement.prototype, "compact", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLDListElement.prototype, "HTMLDListElement", "compact_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLDListElement.prototype, "HTMLDListElement", "compact_set", arguments)}});
