// MIDIInputMap 对象 
MIDIInputMap = function MIDIInputMap(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(MIDIInputMap,"MIDIInputMap");
framevm.toolsFunc.defineProperty(MIDIInputMap.prototype, "size", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, MIDIInputMap.prototype, "MIDIInputMap", "size_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(MIDIInputMap.prototype, "entries", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MIDIInputMap.prototype, "MIDIInputMap", "entries", arguments)}});
framevm.toolsFunc.defineProperty(MIDIInputMap.prototype, "forEach", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MIDIInputMap.prototype, "MIDIInputMap", "forEach", arguments)}});
framevm.toolsFunc.defineProperty(MIDIInputMap.prototype, "get", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MIDIInputMap.prototype, "MIDIInputMap", "get", arguments)}});
framevm.toolsFunc.defineProperty(MIDIInputMap.prototype, "has", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MIDIInputMap.prototype, "MIDIInputMap", "has", arguments)}});
framevm.toolsFunc.defineProperty(MIDIInputMap.prototype, "keys", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MIDIInputMap.prototype, "MIDIInputMap", "keys", arguments)}});
framevm.toolsFunc.defineProperty(MIDIInputMap.prototype, "values", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MIDIInputMap.prototype, "MIDIInputMap", "values", arguments)}});
