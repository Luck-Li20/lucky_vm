// RTCDTMFToneChangeEvent 对象 
RTCDTMFToneChangeEvent = function RTCDTMFToneChangeEvent(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'RTCDTMFToneChangeEvent': 2 arguments required, but only 0 present.");};
framevm.toolsFunc.safeProto(RTCDTMFToneChangeEvent,"RTCDTMFToneChangeEvent");
Object.setPrototypeOf(RTCDTMFToneChangeEvent.prototype, Event.prototype);
framevm.toolsFunc.defineProperty(RTCDTMFToneChangeEvent.prototype, "tone", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, RTCDTMFToneChangeEvent.prototype, "RTCDTMFToneChangeEvent", "tone_get", arguments)}, set:undefined});
