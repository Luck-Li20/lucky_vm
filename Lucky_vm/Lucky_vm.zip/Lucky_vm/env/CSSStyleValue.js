// CSSStyleValue 对象 
CSSStyleValue = function CSSStyleValue(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CSSStyleValue,"CSSStyleValue");
framevm.toolsFunc.defineProperty(CSSStyleValue, "parse", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSStyleValue, "CSSStyleValue", "parse", arguments)}});
framevm.toolsFunc.defineProperty(CSSStyleValue, "parseAll", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSStyleValue, "CSSStyleValue", "parseAll", arguments)}});
framevm.toolsFunc.defineProperty(CSSStyleValue.prototype, "toString", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSStyleValue.prototype, "CSSStyleValue", "toString", arguments)}});
