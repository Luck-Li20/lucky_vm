// Sanitizer 对象 
Sanitizer = function Sanitizer(){};
framevm.toolsFunc.safeProto(Sanitizer,"Sanitizer");
framevm.toolsFunc.defineProperty(Sanitizer, "getDefaultConfiguration", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Sanitizer, "Sanitizer", "getDefaultConfiguration", arguments)}});
framevm.toolsFunc.defineProperty(Sanitizer.prototype, "getConfiguration", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Sanitizer.prototype, "Sanitizer", "getConfiguration", arguments)}});
