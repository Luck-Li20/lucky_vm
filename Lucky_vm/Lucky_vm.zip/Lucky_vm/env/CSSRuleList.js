// CSSRuleList 对象 
CSSRuleList = function CSSRuleList(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CSSRuleList,"CSSRuleList");
framevm.toolsFunc.defineProperty(CSSRuleList.prototype, "length", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSRuleList.prototype, "CSSRuleList", "length_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(CSSRuleList.prototype, "item", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSRuleList.prototype, "CSSRuleList", "item", arguments)}});
framevm.toolsFunc.defineProperty(CSSRuleList.prototype, "values", {configurable:true, enumerable:false, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSRuleList.prototype, "CSSRuleList", "values", arguments)}});
framevm.toolsFunc.defineProperty(CSSRuleList.prototype, "keys", {configurable:true, enumerable:false, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSRuleList.prototype, "CSSRuleList", "keys", arguments)}});
framevm.toolsFunc.defineProperty(CSSRuleList.prototype, "entries", {configurable:true, enumerable:false, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSRuleList.prototype, "CSSRuleList", "entries", arguments)}});
