// HTMLSlotElement 对象 
HTMLSlotElement = function HTMLSlotElement(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(HTMLSlotElement,"HTMLSlotElement");
Object.setPrototypeOf(HTMLSlotElement.prototype, HTMLElement.prototype);
framevm.toolsFunc.defineProperty(HTMLSlotElement.prototype, "name", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLSlotElement.prototype, "HTMLSlotElement", "name_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLSlotElement.prototype, "HTMLSlotElement", "name_set", arguments)}});
framevm.toolsFunc.defineProperty(HTMLSlotElement.prototype, "assign", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, HTMLSlotElement.prototype, "HTMLSlotElement", "assign", arguments)}});
framevm.toolsFunc.defineProperty(HTMLSlotElement.prototype, "assignedElements", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, HTMLSlotElement.prototype, "HTMLSlotElement", "assignedElements", arguments)}});
framevm.toolsFunc.defineProperty(HTMLSlotElement.prototype, "assignedNodes", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, HTMLSlotElement.prototype, "HTMLSlotElement", "assignedNodes", arguments)}});
