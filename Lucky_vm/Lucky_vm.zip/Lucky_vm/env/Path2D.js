// Path2D 对象 
Path2D = function Path2D(){};
framevm.toolsFunc.safeProto(Path2D,"Path2D");
framevm.toolsFunc.defineProperty(Path2D.prototype, "addPath", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Path2D.prototype, "Path2D", "addPath", arguments)}});
framevm.toolsFunc.defineProperty(Path2D.prototype, "roundRect", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Path2D.prototype, "Path2D", "roundRect", arguments)}});
framevm.toolsFunc.defineProperty(Path2D.prototype, "arc", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Path2D.prototype, "Path2D", "arc", arguments)}});
framevm.toolsFunc.defineProperty(Path2D.prototype, "arcTo", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Path2D.prototype, "Path2D", "arcTo", arguments)}});
framevm.toolsFunc.defineProperty(Path2D.prototype, "bezierCurveTo", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Path2D.prototype, "Path2D", "bezierCurveTo", arguments)}});
framevm.toolsFunc.defineProperty(Path2D.prototype, "closePath", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Path2D.prototype, "Path2D", "closePath", arguments)}});
framevm.toolsFunc.defineProperty(Path2D.prototype, "ellipse", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Path2D.prototype, "Path2D", "ellipse", arguments)}});
framevm.toolsFunc.defineProperty(Path2D.prototype, "lineTo", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Path2D.prototype, "Path2D", "lineTo", arguments)}});
framevm.toolsFunc.defineProperty(Path2D.prototype, "moveTo", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Path2D.prototype, "Path2D", "moveTo", arguments)}});
framevm.toolsFunc.defineProperty(Path2D.prototype, "quadraticCurveTo", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Path2D.prototype, "Path2D", "quadraticCurveTo", arguments)}});
framevm.toolsFunc.defineProperty(Path2D.prototype, "rect", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Path2D.prototype, "Path2D", "rect", arguments)}});
