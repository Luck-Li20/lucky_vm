// PerformancePaintTiming 对象 
PerformancePaintTiming = function PerformancePaintTiming(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(PerformancePaintTiming,"PerformancePaintTiming");
Object.setPrototypeOf(PerformancePaintTiming.prototype, PerformanceEntry.prototype);
