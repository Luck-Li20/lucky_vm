// CSSLayerStatementRule 对象 
CSSLayerStatementRule = function CSSLayerStatementRule(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CSSLayerStatementRule,"CSSLayerStatementRule");
Object.setPrototypeOf(CSSLayerStatementRule.prototype, CSSRule.prototype);
framevm.toolsFunc.defineProperty(CSSLayerStatementRule.prototype, "nameList", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSLayerStatementRule.prototype, "CSSLayerStatementRule", "nameList_get", arguments)}, set:undefined});
