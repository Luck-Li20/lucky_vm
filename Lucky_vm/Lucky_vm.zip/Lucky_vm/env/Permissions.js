// Permissions 对象
Permissions = function Permissions(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(Permissions,"Permissions");
framevm.toolsFunc.defineProperty(Permissions.prototype, "query", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Permissions.prototype, "Permissions", "query", arguments)}});
