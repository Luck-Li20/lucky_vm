// CSSFontPaletteValuesRule 对象 
CSSFontPaletteValuesRule = function CSSFontPaletteValuesRule(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CSSFontPaletteValuesRule,"CSSFontPaletteValuesRule");
Object.setPrototypeOf(CSSFontPaletteValuesRule.prototype, CSSRule.prototype);
framevm.toolsFunc.defineProperty(CSSFontPaletteValuesRule.prototype, "name", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSFontPaletteValuesRule.prototype, "CSSFontPaletteValuesRule", "name_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(CSSFontPaletteValuesRule.prototype, "fontFamily", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSFontPaletteValuesRule.prototype, "CSSFontPaletteValuesRule", "fontFamily_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(CSSFontPaletteValuesRule.prototype, "basePalette", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSFontPaletteValuesRule.prototype, "CSSFontPaletteValuesRule", "basePalette_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(CSSFontPaletteValuesRule.prototype, "overrideColors", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSFontPaletteValuesRule.prototype, "CSSFontPaletteValuesRule", "overrideColors_get", arguments)}, set:undefined});
