// MediaSourceHandle 对象 
MediaSourceHandle = function MediaSourceHandle(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(MediaSourceHandle,"MediaSourceHandle");
