// ReadableStreamBYOBRequest 对象 
ReadableStreamBYOBRequest = function ReadableStreamBYOBRequest(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(ReadableStreamBYOBRequest,"ReadableStreamBYOBRequest");
framevm.toolsFunc.defineProperty(ReadableStreamBYOBRequest.prototype, "view", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, ReadableStreamBYOBRequest.prototype, "ReadableStreamBYOBRequest", "view_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(ReadableStreamBYOBRequest.prototype, "respond", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, ReadableStreamBYOBRequest.prototype, "ReadableStreamBYOBRequest", "respond", arguments)}});
framevm.toolsFunc.defineProperty(ReadableStreamBYOBRequest.prototype, "respondWithNewView", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, ReadableStreamBYOBRequest.prototype, "ReadableStreamBYOBRequest", "respondWithNewView", arguments)}});
