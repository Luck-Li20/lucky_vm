// NavigationCurrentEntryChangeEvent 对象 
NavigationCurrentEntryChangeEvent = function NavigationCurrentEntryChangeEvent(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'NavigationCurrentEntryChangeEvent': 2 arguments required, but only 0 present.");};
framevm.toolsFunc.safeProto(NavigationCurrentEntryChangeEvent,"NavigationCurrentEntryChangeEvent");
Object.setPrototypeOf(NavigationCurrentEntryChangeEvent.prototype, Event.prototype);
framevm.toolsFunc.defineProperty(NavigationCurrentEntryChangeEvent.prototype, "navigationType", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, NavigationCurrentEntryChangeEvent.prototype, "NavigationCurrentEntryChangeEvent", "navigationType_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(NavigationCurrentEntryChangeEvent.prototype, "from", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, NavigationCurrentEntryChangeEvent.prototype, "NavigationCurrentEntryChangeEvent", "from_get", arguments)}, set:undefined});
