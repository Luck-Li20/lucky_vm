// FeaturePolicy 对象 
FeaturePolicy = function FeaturePolicy(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(FeaturePolicy,"FeaturePolicy");
framevm.toolsFunc.defineProperty(FeaturePolicy.prototype, "allowedFeatures", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FeaturePolicy.prototype, "FeaturePolicy", "allowedFeatures", arguments)}});
framevm.toolsFunc.defineProperty(FeaturePolicy.prototype, "allowsFeature", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FeaturePolicy.prototype, "FeaturePolicy", "allowsFeature", arguments)}});
framevm.toolsFunc.defineProperty(FeaturePolicy.prototype, "features", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FeaturePolicy.prototype, "FeaturePolicy", "features", arguments)}});
framevm.toolsFunc.defineProperty(FeaturePolicy.prototype, "getAllowlistForFeature", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, FeaturePolicy.prototype, "FeaturePolicy", "getAllowlistForFeature", arguments)}});
