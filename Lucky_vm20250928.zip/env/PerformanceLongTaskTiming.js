// PerformanceLongTaskTiming 对象 
PerformanceLongTaskTiming = function PerformanceLongTaskTiming(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(PerformanceLongTaskTiming,"PerformanceLongTaskTiming");
Object.setPrototypeOf(PerformanceLongTaskTiming.prototype, PerformanceEntry.prototype);
framevm.toolsFunc.defineProperty(PerformanceLongTaskTiming.prototype, "attribution", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, PerformanceLongTaskTiming.prototype, "PerformanceLongTaskTiming", "attribution_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(PerformanceLongTaskTiming.prototype, "toJSON", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, PerformanceLongTaskTiming.prototype, "PerformanceLongTaskTiming", "toJSON", arguments)}});
