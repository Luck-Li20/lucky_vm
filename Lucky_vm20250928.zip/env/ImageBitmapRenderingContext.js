// ImageBitmapRenderingContext 对象 
ImageBitmapRenderingContext = function ImageBitmapRenderingContext(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(ImageBitmapRenderingContext,"ImageBitmapRenderingContext");
framevm.toolsFunc.defineProperty(ImageBitmapRenderingContext.prototype, "canvas", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, ImageBitmapRenderingContext.prototype, "ImageBitmapRenderingContext", "canvas_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(ImageBitmapRenderingContext.prototype, "transferFromImageBitmap", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, ImageBitmapRenderingContext.prototype, "ImageBitmapRenderingContext", "transferFromImageBitmap", arguments)}});
