// HTMLFontElement 对象
HTMLFontElement = function HTMLFontElement(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(HTMLFontElement,"HTMLFontElement");
Object.setPrototypeOf(HTMLFontElement.prototype, HTMLElement.prototype);
framevm.toolsFunc.defineProperty(HTMLFontElement.prototype, "color", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLFontElement.prototype, "HTMLFontElement", "color_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLFontElement.prototype, "HTMLFontElement", "color_set", arguments)}});
framevm.toolsFunc.defineProperty(HTMLFontElement.prototype, "face", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLFontElement.prototype, "HTMLFontElement", "face_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLFontElement.prototype, "HTMLFontElement", "face_set", arguments)}});
framevm.toolsFunc.defineProperty(HTMLFontElement.prototype, "size", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLFontElement.prototype, "HTMLFontElement", "size_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLFontElement.prototype, "HTMLFontElement", "size_set", arguments)}});
