// CaptureController 对象 
CaptureController = function CaptureController(){};
framevm.toolsFunc.safeProto(CaptureController,"CaptureController");
framevm.toolsFunc.defineProperty(CaptureController.prototype, "setFocusBehavior", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CaptureController.prototype, "CaptureController", "setFocusBehavior", arguments)}});
