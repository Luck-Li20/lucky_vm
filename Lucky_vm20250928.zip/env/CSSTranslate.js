// CSSTranslate 对象 
CSSTranslate = function CSSTranslate(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'CSSTranslate': 2 arguments required, but only 0 present.");};
framevm.toolsFunc.safeProto(CSSTranslate,"CSSTranslate");
Object.setPrototypeOf(CSSTranslate.prototype, CSSTransformComponent.prototype);
framevm.toolsFunc.defineProperty(CSSTranslate.prototype, "x", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSTranslate.prototype, "CSSTranslate", "x_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, CSSTranslate.prototype, "CSSTranslate", "x_set", arguments)}});
framevm.toolsFunc.defineProperty(CSSTranslate.prototype, "y", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSTranslate.prototype, "CSSTranslate", "y_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, CSSTranslate.prototype, "CSSTranslate", "y_set", arguments)}});
framevm.toolsFunc.defineProperty(CSSTranslate.prototype, "z", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSTranslate.prototype, "CSSTranslate", "z_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, CSSTranslate.prototype, "CSSTranslate", "z_set", arguments)}});
