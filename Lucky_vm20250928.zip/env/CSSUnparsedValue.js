// CSSUnparsedValue 对象 
CSSUnparsedValue = function CSSUnparsedValue(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'CSSUnparsedValue': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(CSSUnparsedValue,"CSSUnparsedValue");
Object.setPrototypeOf(CSSUnparsedValue.prototype, CSSStyleValue.prototype);
framevm.toolsFunc.defineProperty(CSSUnparsedValue.prototype, "entries", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSUnparsedValue.prototype, "CSSUnparsedValue", "entries", arguments)}});
framevm.toolsFunc.defineProperty(CSSUnparsedValue.prototype, "keys", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSUnparsedValue.prototype, "CSSUnparsedValue", "keys", arguments)}});
framevm.toolsFunc.defineProperty(CSSUnparsedValue.prototype, "values", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSUnparsedValue.prototype, "CSSUnparsedValue", "values", arguments)}});
framevm.toolsFunc.defineProperty(CSSUnparsedValue.prototype, "forEach", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSUnparsedValue.prototype, "CSSUnparsedValue", "forEach", arguments)}});
framevm.toolsFunc.defineProperty(CSSUnparsedValue.prototype, "length", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSUnparsedValue.prototype, "CSSUnparsedValue", "length_get", arguments)}, set:undefined});
