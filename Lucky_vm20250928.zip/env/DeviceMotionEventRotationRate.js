// DeviceMotionEventRotationRate 对象 
DeviceMotionEventRotationRate = function DeviceMotionEventRotationRate(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(DeviceMotionEventRotationRate,"DeviceMotionEventRotationRate");
framevm.toolsFunc.defineProperty(DeviceMotionEventRotationRate.prototype, "alpha", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DeviceMotionEventRotationRate.prototype, "DeviceMotionEventRotationRate", "alpha_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DeviceMotionEventRotationRate.prototype, "beta", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DeviceMotionEventRotationRate.prototype, "DeviceMotionEventRotationRate", "beta_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DeviceMotionEventRotationRate.prototype, "gamma", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DeviceMotionEventRotationRate.prototype, "DeviceMotionEventRotationRate", "gamma_get", arguments)}, set:undefined});
