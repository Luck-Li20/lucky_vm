// CSSSkewY 对象 
CSSSkewY = function CSSSkewY(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'CSSSkewY': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(CSSSkewY,"CSSSkewY");
Object.setPrototypeOf(CSSSkewY.prototype, CSSTransformComponent.prototype);
framevm.toolsFunc.defineProperty(CSSSkewY.prototype, "ay", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSSkewY.prototype, "CSSSkewY", "ay_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, CSSSkewY.prototype, "CSSSkewY", "ay_set", arguments)}});
