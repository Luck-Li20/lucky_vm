// CustomElementRegistry 对象 
CustomElementRegistry = function CustomElementRegistry(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CustomElementRegistry,"CustomElementRegistry");
framevm.toolsFunc.defineProperty(CustomElementRegistry.prototype, "define", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CustomElementRegistry.prototype, "CustomElementRegistry", "define", arguments)}});
framevm.toolsFunc.defineProperty(CustomElementRegistry.prototype, "get", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CustomElementRegistry.prototype, "CustomElementRegistry", "get", arguments)}});
framevm.toolsFunc.defineProperty(CustomElementRegistry.prototype, "upgrade", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CustomElementRegistry.prototype, "CustomElementRegistry", "upgrade", arguments)}});
framevm.toolsFunc.defineProperty(CustomElementRegistry.prototype, "whenDefined", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CustomElementRegistry.prototype, "CustomElementRegistry", "whenDefined", arguments)}});
