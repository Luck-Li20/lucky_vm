// CookieStoreManager 对象 
CookieStoreManager = function CookieStoreManager(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CookieStoreManager,"CookieStoreManager");
framevm.toolsFunc.defineProperty(CookieStoreManager.prototype, "getSubscriptions", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CookieStoreManager.prototype, "CookieStoreManager", "getSubscriptions", arguments)}});
framevm.toolsFunc.defineProperty(CookieStoreManager.prototype, "subscribe", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CookieStoreManager.prototype, "CookieStoreManager", "subscribe", arguments)}});
framevm.toolsFunc.defineProperty(CookieStoreManager.prototype, "unsubscribe", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CookieStoreManager.prototype, "CookieStoreManager", "unsubscribe", arguments)}});
