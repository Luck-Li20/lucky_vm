// PerformanceObserver 对象 
PerformanceObserver = function PerformanceObserver(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'PerformanceObserver': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(PerformanceObserver,"PerformanceObserver");
framevm.toolsFunc.defineProperty(PerformanceObserver, "supportedEntryTypes", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, PerformanceObserver, "PerformanceObserver", "supportedEntryTypes_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(PerformanceObserver.prototype, "disconnect", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, PerformanceObserver.prototype, "PerformanceObserver", "disconnect", arguments)}});
framevm.toolsFunc.defineProperty(PerformanceObserver.prototype, "observe", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, PerformanceObserver.prototype, "PerformanceObserver", "observe", arguments)}});
framevm.toolsFunc.defineProperty(PerformanceObserver.prototype, "takeRecords", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, PerformanceObserver.prototype, "PerformanceObserver", "takeRecords", arguments)}});
