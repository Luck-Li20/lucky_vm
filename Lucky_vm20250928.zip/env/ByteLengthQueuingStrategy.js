// ByteLengthQueuingStrategy 对象 
ByteLengthQueuingStrategy = function ByteLengthQueuingStrategy(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'ByteLengthQueuingStrategy': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(ByteLengthQueuingStrategy,"ByteLengthQueuingStrategy");
framevm.toolsFunc.defineProperty(ByteLengthQueuingStrategy.prototype, "highWaterMark", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, ByteLengthQueuingStrategy.prototype, "ByteLengthQueuingStrategy", "highWaterMark_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(ByteLengthQueuingStrategy.prototype, "size", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, ByteLengthQueuingStrategy.prototype, "ByteLengthQueuingStrategy", "size_get", arguments)}, set:undefined});
