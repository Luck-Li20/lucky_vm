// AuthenticatorResponse 对象 
AuthenticatorResponse = function AuthenticatorResponse(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(AuthenticatorResponse,"AuthenticatorResponse");
framevm.toolsFunc.defineProperty(AuthenticatorResponse.prototype, "clientDataJSON", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, AuthenticatorResponse.prototype, "AuthenticatorResponse", "clientDataJSON_get", arguments)}, set:undefined});
