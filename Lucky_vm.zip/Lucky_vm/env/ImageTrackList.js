// ImageTrackList 对象 
ImageTrackList = function ImageTrackList(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(ImageTrackList,"ImageTrackList");
framevm.toolsFunc.defineProperty(ImageTrackList.prototype, "length", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, ImageTrackList.prototype, "ImageTrackList", "length_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(ImageTrackList.prototype, "selectedIndex", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, ImageTrackList.prototype, "ImageTrackList", "selectedIndex_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(ImageTrackList.prototype, "selectedTrack", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, ImageTrackList.prototype, "ImageTrackList", "selectedTrack_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(ImageTrackList.prototype, "ready", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, ImageTrackList.prototype, "ImageTrackList", "ready_get", arguments)}, set:undefined});
