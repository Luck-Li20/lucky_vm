// IDBKeyRange 对象 
IDBKeyRange = function IDBKeyRange(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(IDBKeyRange,"IDBKeyRange");
framevm.toolsFunc.defineProperty(IDBKeyRange, "bound", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, IDBKeyRange, "IDBKeyRange", "bound", arguments)}});
framevm.toolsFunc.defineProperty(IDBKeyRange, "lowerBound", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, IDBKeyRange, "IDBKeyRange", "lowerBound", arguments)}});
framevm.toolsFunc.defineProperty(IDBKeyRange, "only", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, IDBKeyRange, "IDBKeyRange", "only", arguments)}});
framevm.toolsFunc.defineProperty(IDBKeyRange, "upperBound", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, IDBKeyRange, "IDBKeyRange", "upperBound", arguments)}});
framevm.toolsFunc.defineProperty(IDBKeyRange.prototype, "lower", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, IDBKeyRange.prototype, "IDBKeyRange", "lower_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(IDBKeyRange.prototype, "upper", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, IDBKeyRange.prototype, "IDBKeyRange", "upper_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(IDBKeyRange.prototype, "lowerOpen", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, IDBKeyRange.prototype, "IDBKeyRange", "lowerOpen_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(IDBKeyRange.prototype, "upperOpen", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, IDBKeyRange.prototype, "IDBKeyRange", "upperOpen_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(IDBKeyRange.prototype, "includes", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, IDBKeyRange.prototype, "IDBKeyRange", "includes", arguments)}});
