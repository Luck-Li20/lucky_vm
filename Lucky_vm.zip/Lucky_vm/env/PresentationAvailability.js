// PresentationAvailability 对象 
PresentationAvailability = function PresentationAvailability(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(PresentationAvailability,"PresentationAvailability");
Object.setPrototypeOf(PresentationAvailability.prototype, EventTarget.prototype);
framevm.toolsFunc.defineProperty(PresentationAvailability.prototype, "value", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, PresentationAvailability.prototype, "PresentationAvailability", "value_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(PresentationAvailability.prototype, "onchange", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, PresentationAvailability.prototype, "PresentationAvailability", "onchange_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, PresentationAvailability.prototype, "PresentationAvailability", "onchange_set", arguments)}});
