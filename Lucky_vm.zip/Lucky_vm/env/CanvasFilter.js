// CanvasFilter 对象 
CanvasFilter = function CanvasFilter(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'CanvasFilter': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(CanvasFilter,"CanvasFilter");
