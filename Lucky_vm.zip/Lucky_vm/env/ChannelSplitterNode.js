// ChannelSplitterNode 对象 
ChannelSplitterNode = function ChannelSplitterNode(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'ChannelSplitterNode': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(ChannelSplitterNode,"ChannelSplitterNode");
Object.setPrototypeOf(ChannelSplitterNode.prototype, AudioNode.prototype);
