// MediaStreamTrackProcessor 对象 
MediaStreamTrackProcessor = function MediaStreamTrackProcessor(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'MediaStreamTrackProcessor': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(MediaStreamTrackProcessor,"MediaStreamTrackProcessor");
framevm.toolsFunc.defineProperty(MediaStreamTrackProcessor.prototype, "readable", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, MediaStreamTrackProcessor.prototype, "MediaStreamTrackProcessor", "readable_get", arguments)}, set:undefined});
