// PeriodicWave 对象 
PeriodicWave = function PeriodicWave(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'PeriodicWave': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(PeriodicWave,"PeriodicWave");
