// PaymentRequestUpdateEvent 对象 
PaymentRequestUpdateEvent = function PaymentRequestUpdateEvent(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'PaymentRequestUpdateEvent': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(PaymentRequestUpdateEvent,"PaymentRequestUpdateEvent");
Object.setPrototypeOf(PaymentRequestUpdateEvent.prototype, Event.prototype);
framevm.toolsFunc.defineProperty(PaymentRequestUpdateEvent.prototype, "updateWith", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, PaymentRequestUpdateEvent.prototype, "PaymentRequestUpdateEvent", "updateWith", arguments)}});
