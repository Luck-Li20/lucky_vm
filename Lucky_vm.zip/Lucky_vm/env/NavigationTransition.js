// NavigationTransition 对象 
NavigationTransition = function NavigationTransition(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(NavigationTransition,"NavigationTransition");
framevm.toolsFunc.defineProperty(NavigationTransition.prototype, "navigationType", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, NavigationTransition.prototype, "NavigationTransition", "navigationType_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(NavigationTransition.prototype, "from", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, NavigationTransition.prototype, "NavigationTransition", "from_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(NavigationTransition.prototype, "finished", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, NavigationTransition.prototype, "NavigationTransition", "finished_get", arguments)}, set:undefined});
