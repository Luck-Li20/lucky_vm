// DeviceMotionEventAcceleration 对象 
DeviceMotionEventAcceleration = function DeviceMotionEventAcceleration(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(DeviceMotionEventAcceleration,"DeviceMotionEventAcceleration");
framevm.toolsFunc.defineProperty(DeviceMotionEventAcceleration.prototype, "x", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DeviceMotionEventAcceleration.prototype, "DeviceMotionEventAcceleration", "x_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DeviceMotionEventAcceleration.prototype, "y", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DeviceMotionEventAcceleration.prototype, "DeviceMotionEventAcceleration", "y_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DeviceMotionEventAcceleration.prototype, "z", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DeviceMotionEventAcceleration.prototype, "DeviceMotionEventAcceleration", "z_get", arguments)}, set:undefined});
