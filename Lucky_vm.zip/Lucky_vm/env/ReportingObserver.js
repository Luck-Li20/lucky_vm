// ReportingObserver 对象 
ReportingObserver = function ReportingObserver(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'ReportingObserver': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(ReportingObserver,"ReportingObserver");
framevm.toolsFunc.defineProperty(ReportingObserver.prototype, "disconnect", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, ReportingObserver.prototype, "ReportingObserver", "disconnect", arguments)}});
framevm.toolsFunc.defineProperty(ReportingObserver.prototype, "observe", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, ReportingObserver.prototype, "ReportingObserver", "observe", arguments)}});
framevm.toolsFunc.defineProperty(ReportingObserver.prototype, "takeRecords", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, ReportingObserver.prototype, "ReportingObserver", "takeRecords", arguments)}});
