// CountQueuingStrategy 对象 
CountQueuingStrategy = function CountQueuingStrategy(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'CountQueuingStrategy': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(CountQueuingStrategy,"CountQueuingStrategy");
framevm.toolsFunc.defineProperty(CountQueuingStrategy.prototype, "highWaterMark", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CountQueuingStrategy.prototype, "CountQueuingStrategy", "highWaterMark_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(CountQueuingStrategy.prototype, "size", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CountQueuingStrategy.prototype, "CountQueuingStrategy", "size_get", arguments)}, set:undefined});
