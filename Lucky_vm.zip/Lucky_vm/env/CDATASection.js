// CDATASection 对象 
CDATASection = function CDATASection(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CDATASection,"CDATASection");
Object.setPrototypeOf(CDATASection.prototype, Text.prototype);
