// Headers 对象 
Headers = function Headers(){};
framevm.toolsFunc.safeProto(Headers,"Headers");
framevm.toolsFunc.defineProperty(Headers.prototype, "append", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Headers.prototype, "Headers", "append", arguments)}});
framevm.toolsFunc.defineProperty(Headers.prototype, "delete", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Headers.prototype, "Headers", "delete", arguments)}});
framevm.toolsFunc.defineProperty(Headers.prototype, "get", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Headers.prototype, "Headers", "get", arguments)}});
framevm.toolsFunc.defineProperty(Headers.prototype, "has", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Headers.prototype, "Headers", "has", arguments)}});
framevm.toolsFunc.defineProperty(Headers.prototype, "set", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Headers.prototype, "Headers", "set", arguments)}});
framevm.toolsFunc.defineProperty(Headers.prototype, "entries", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Headers.prototype, "Headers", "entries", arguments)}});
framevm.toolsFunc.defineProperty(Headers.prototype, "forEach", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Headers.prototype, "Headers", "forEach", arguments)}});
framevm.toolsFunc.defineProperty(Headers.prototype, "keys", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Headers.prototype, "Headers", "keys", arguments)}});
framevm.toolsFunc.defineProperty(Headers.prototype, "values", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Headers.prototype, "Headers", "values", arguments)}});
