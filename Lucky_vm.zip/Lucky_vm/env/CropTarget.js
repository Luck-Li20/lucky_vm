// CropTarget 对象 
CropTarget = function CropTarget(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CropTarget,"CropTarget");
framevm.toolsFunc.defineProperty(CropTarget, "fromElement", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CropTarget, "CropTarget", "fromElement", arguments)}});
