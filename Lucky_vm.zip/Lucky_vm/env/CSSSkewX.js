// CSSSkewX 对象 
CSSSkewX = function CSSSkewX(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'CSSSkewX': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(CSSSkewX,"CSSSkewX");
Object.setPrototypeOf(CSSSkewX.prototype, CSSTransformComponent.prototype);
framevm.toolsFunc.defineProperty(CSSSkewX.prototype, "ax", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSSkewX.prototype, "CSSSkewX", "ax_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, CSSSkewX.prototype, "CSSSkewX", "ax_set", arguments)}});
