// HTMLTableCaptionElement 对象 
HTMLTableCaptionElement = function HTMLTableCaptionElement(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(HTMLTableCaptionElement,"HTMLTableCaptionElement");
Object.setPrototypeOf(HTMLTableCaptionElement.prototype, HTMLElement.prototype);
framevm.toolsFunc.defineProperty(HTMLTableCaptionElement.prototype, "align", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLTableCaptionElement.prototype, "HTMLTableCaptionElement", "align_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLTableCaptionElement.prototype, "HTMLTableCaptionElement", "align_set", arguments)}});
