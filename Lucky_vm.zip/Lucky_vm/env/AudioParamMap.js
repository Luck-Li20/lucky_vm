// AudioParamMap 对象 
AudioParamMap = function AudioParamMap(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(AudioParamMap,"AudioParamMap");
framevm.toolsFunc.defineProperty(AudioParamMap.prototype, "size", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, AudioParamMap.prototype, "AudioParamMap", "size_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(AudioParamMap.prototype, "entries", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, AudioParamMap.prototype, "AudioParamMap", "entries", arguments)}});
framevm.toolsFunc.defineProperty(AudioParamMap.prototype, "forEach", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, AudioParamMap.prototype, "AudioParamMap", "forEach", arguments)}});
framevm.toolsFunc.defineProperty(AudioParamMap.prototype, "get", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, AudioParamMap.prototype, "AudioParamMap", "get", arguments)}});
framevm.toolsFunc.defineProperty(AudioParamMap.prototype, "has", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, AudioParamMap.prototype, "AudioParamMap", "has", arguments)}});
framevm.toolsFunc.defineProperty(AudioParamMap.prototype, "keys", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, AudioParamMap.prototype, "AudioParamMap", "keys", arguments)}});
framevm.toolsFunc.defineProperty(AudioParamMap.prototype, "values", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, AudioParamMap.prototype, "AudioParamMap", "values", arguments)}});
