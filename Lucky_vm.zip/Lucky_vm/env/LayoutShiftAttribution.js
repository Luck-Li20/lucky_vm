// LayoutShiftAttribution 对象 
LayoutShiftAttribution = function LayoutShiftAttribution(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(LayoutShiftAttribution,"LayoutShiftAttribution");
framevm.toolsFunc.defineProperty(LayoutShiftAttribution.prototype, "node", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, LayoutShiftAttribution.prototype, "LayoutShiftAttribution", "node_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(LayoutShiftAttribution.prototype, "previousRect", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, LayoutShiftAttribution.prototype, "LayoutShiftAttribution", "previousRect_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(LayoutShiftAttribution.prototype, "currentRect", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, LayoutShiftAttribution.prototype, "LayoutShiftAttribution", "currentRect_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(LayoutShiftAttribution.prototype, "toJSON", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, LayoutShiftAttribution.prototype, "LayoutShiftAttribution", "toJSON", arguments)}});
