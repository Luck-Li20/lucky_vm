// CSSLayerBlockRule 对象 
CSSLayerBlockRule = function CSSLayerBlockRule(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CSSLayerBlockRule,"CSSLayerBlockRule");
Object.setPrototypeOf(CSSLayerBlockRule.prototype, CSSGroupingRule.prototype);
framevm.toolsFunc.defineProperty(CSSLayerBlockRule.prototype, "name", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSLayerBlockRule.prototype, "CSSLayerBlockRule", "name_get", arguments)}, set:undefined});
