// CSSNumericArray 对象 
CSSNumericArray = function CSSNumericArray(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CSSNumericArray,"CSSNumericArray");
framevm.toolsFunc.defineProperty(CSSNumericArray.prototype, "entries", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSNumericArray.prototype, "CSSNumericArray", "entries", arguments)}});
framevm.toolsFunc.defineProperty(CSSNumericArray.prototype, "keys", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSNumericArray.prototype, "CSSNumericArray", "keys", arguments)}});
framevm.toolsFunc.defineProperty(CSSNumericArray.prototype, "values", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSNumericArray.prototype, "CSSNumericArray", "values", arguments)}});
framevm.toolsFunc.defineProperty(CSSNumericArray.prototype, "forEach", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSNumericArray.prototype, "CSSNumericArray", "forEach", arguments)}});
framevm.toolsFunc.defineProperty(CSSNumericArray.prototype, "length", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSNumericArray.prototype, "CSSNumericArray", "length_get", arguments)}, set:undefined});
