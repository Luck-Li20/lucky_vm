// DataTransferItemList 对象 
DataTransferItemList = function DataTransferItemList(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(DataTransferItemList,"DataTransferItemList");
framevm.toolsFunc.defineProperty(DataTransferItemList.prototype, "length", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DataTransferItemList.prototype, "DataTransferItemList", "length_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DataTransferItemList.prototype, "add", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, DataTransferItemList.prototype, "DataTransferItemList", "add", arguments)}});
framevm.toolsFunc.defineProperty(DataTransferItemList.prototype, "clear", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, DataTransferItemList.prototype, "DataTransferItemList", "clear", arguments)}});
framevm.toolsFunc.defineProperty(DataTransferItemList.prototype, "remove", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, DataTransferItemList.prototype, "DataTransferItemList", "remove", arguments)}});
