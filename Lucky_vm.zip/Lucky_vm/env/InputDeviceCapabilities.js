// InputDeviceCapabilities 对象 
InputDeviceCapabilities = function InputDeviceCapabilities(){};
framevm.toolsFunc.safeProto(InputDeviceCapabilities,"InputDeviceCapabilities");
framevm.toolsFunc.defineProperty(InputDeviceCapabilities.prototype, "firesTouchEvents", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, InputDeviceCapabilities.prototype, "InputDeviceCapabilities", "firesTouchEvents_get", arguments)}, set:undefined});
