// CSSSupportsRule 对象 
CSSSupportsRule = function CSSSupportsRule(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CSSSupportsRule,"CSSSupportsRule");
Object.setPrototypeOf(CSSSupportsRule.prototype, CSSConditionRule.prototype);
