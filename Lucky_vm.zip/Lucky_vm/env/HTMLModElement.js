// HTMLModElement 对象 
HTMLModElement = function HTMLModElement(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(HTMLModElement,"HTMLModElement");
Object.setPrototypeOf(HTMLModElement.prototype, HTMLElement.prototype);
framevm.toolsFunc.defineProperty(HTMLModElement.prototype, "cite", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLModElement.prototype, "HTMLModElement", "cite_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLModElement.prototype, "HTMLModElement", "cite_set", arguments)}});
framevm.toolsFunc.defineProperty(HTMLModElement.prototype, "dateTime", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLModElement.prototype, "HTMLModElement", "dateTime_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLModElement.prototype, "HTMLModElement", "dateTime_set", arguments)}});
