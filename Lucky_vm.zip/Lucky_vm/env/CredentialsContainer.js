// CredentialsContainer 对象
CredentialsContainer = function CredentialsContainer(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CredentialsContainer,"CredentialsContainer");
framevm.toolsFunc.defineProperty(CredentialsContainer.prototype, "create", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CredentialsContainer.prototype, "CredentialsContainer", "create", arguments)}});
framevm.toolsFunc.defineProperty(CredentialsContainer.prototype, "get", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CredentialsContainer.prototype, "CredentialsContainer", "get", arguments)}});
framevm.toolsFunc.defineProperty(CredentialsContainer.prototype, "preventSilentAccess", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CredentialsContainer.prototype, "CredentialsContainer", "preventSilentAccess", arguments)}});
framevm.toolsFunc.defineProperty(CredentialsContainer.prototype, "store", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CredentialsContainer.prototype, "CredentialsContainer", "store", arguments)}});
