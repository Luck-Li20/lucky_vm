// ChannelMergerNode 对象 
ChannelMergerNode = function ChannelMergerNode(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'ChannelMergerNode': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(ChannelMergerNode,"ChannelMergerNode");
Object.setPrototypeOf(ChannelMergerNode.prototype, AudioNode.prototype);
