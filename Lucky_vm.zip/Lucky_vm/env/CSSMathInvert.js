// CSSMathInvert 对象 
CSSMathInvert = function CSSMathInvert(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'CSSMathInvert': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(CSSMathInvert,"CSSMathInvert");
Object.setPrototypeOf(CSSMathInvert.prototype, CSSMathValue.prototype);
framevm.toolsFunc.defineProperty(CSSMathInvert.prototype, "value", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSMathInvert.prototype, "CSSMathInvert", "value_get", arguments)}, set:undefined});
