// NavigationPreloadManager 对象 
NavigationPreloadManager = function NavigationPreloadManager(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(NavigationPreloadManager,"NavigationPreloadManager");
framevm.toolsFunc.defineProperty(NavigationPreloadManager.prototype, "disable", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, NavigationPreloadManager.prototype, "NavigationPreloadManager", "disable", arguments)}});
framevm.toolsFunc.defineProperty(NavigationPreloadManager.prototype, "enable", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, NavigationPreloadManager.prototype, "NavigationPreloadManager", "enable", arguments)}});
framevm.toolsFunc.defineProperty(NavigationPreloadManager.prototype, "getState", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, NavigationPreloadManager.prototype, "NavigationPreloadManager", "getState", arguments)}});
framevm.toolsFunc.defineProperty(NavigationPreloadManager.prototype, "setHeaderValue", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, NavigationPreloadManager.prototype, "NavigationPreloadManager", "setHeaderValue", arguments)}});
