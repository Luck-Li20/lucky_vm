// GamepadHapticActuator 对象 
GamepadHapticActuator = function GamepadHapticActuator(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(GamepadHapticActuator,"GamepadHapticActuator");
framevm.toolsFunc.defineProperty(GamepadHapticActuator.prototype, "type", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, GamepadHapticActuator.prototype, "GamepadHapticActuator", "type_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(GamepadHapticActuator.prototype, "playEffect", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, GamepadHapticActuator.prototype, "GamepadHapticActuator", "playEffect", arguments)}});
framevm.toolsFunc.defineProperty(GamepadHapticActuator.prototype, "reset", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, GamepadHapticActuator.prototype, "GamepadHapticActuator", "reset", arguments)}});
