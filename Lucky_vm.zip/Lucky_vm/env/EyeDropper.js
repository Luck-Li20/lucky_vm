// EyeDropper 对象 
EyeDropper = function EyeDropper(){};
framevm.toolsFunc.safeProto(EyeDropper,"EyeDropper");
framevm.toolsFunc.defineProperty(EyeDropper.prototype, "open", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, EyeDropper.prototype, "EyeDropper", "open", arguments)}});
