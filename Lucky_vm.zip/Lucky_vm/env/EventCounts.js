// EventCounts 对象
EventCounts = function EventCounts(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(EventCounts,"EventCounts");
framevm.toolsFunc.defineProperty(EventCounts.prototype, "size", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, EventCounts.prototype, "EventCounts", "size_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(EventCounts.prototype, "entries", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, EventCounts.prototype, "EventCounts", "entries", arguments)}});
framevm.toolsFunc.defineProperty(EventCounts.prototype, "forEach", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, EventCounts.prototype, "EventCounts", "forEach", arguments)}});
framevm.toolsFunc.defineProperty(EventCounts.prototype, "get", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, EventCounts.prototype, "EventCounts", "get", arguments)}});
framevm.toolsFunc.defineProperty(EventCounts.prototype, "has", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, EventCounts.prototype, "EventCounts", "has", arguments)}});
framevm.toolsFunc.defineProperty(EventCounts.prototype, "keys", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, EventCounts.prototype, "EventCounts", "keys", arguments)}});
framevm.toolsFunc.defineProperty(EventCounts.prototype, "values", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, EventCounts.prototype, "EventCounts", "values", arguments)}});
