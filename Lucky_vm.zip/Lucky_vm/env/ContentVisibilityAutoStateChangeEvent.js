// ContentVisibilityAutoStateChangeEvent 对象 
ContentVisibilityAutoStateChangeEvent = function ContentVisibilityAutoStateChangeEvent(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'ContentVisibilityAutoStateChangeEvent': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(ContentVisibilityAutoStateChangeEvent,"ContentVisibilityAutoStateChangeEvent");
Object.setPrototypeOf(ContentVisibilityAutoStateChangeEvent.prototype, Event.prototype);
framevm.toolsFunc.defineProperty(ContentVisibilityAutoStateChangeEvent.prototype, "skipped", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, ContentVisibilityAutoStateChangeEvent.prototype, "ContentVisibilityAutoStateChangeEvent", "skipped_get", arguments)}, set:undefined});
