// DOMPointReadOnly 对象 
DOMPointReadOnly = function DOMPointReadOnly(){};
framevm.toolsFunc.safeProto(DOMPointReadOnly,"DOMPointReadOnly");
framevm.toolsFunc.defineProperty(DOMPointReadOnly, "fromPoint", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, DOMPointReadOnly, "DOMPointReadOnly", "fromPoint", arguments)}});
framevm.toolsFunc.defineProperty(DOMPointReadOnly.prototype, "x", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DOMPointReadOnly.prototype, "DOMPointReadOnly", "x_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DOMPointReadOnly.prototype, "y", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DOMPointReadOnly.prototype, "DOMPointReadOnly", "y_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DOMPointReadOnly.prototype, "z", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DOMPointReadOnly.prototype, "DOMPointReadOnly", "z_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DOMPointReadOnly.prototype, "w", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DOMPointReadOnly.prototype, "DOMPointReadOnly", "w_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DOMPointReadOnly.prototype, "matrixTransform", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, DOMPointReadOnly.prototype, "DOMPointReadOnly", "matrixTransform", arguments)}});
framevm.toolsFunc.defineProperty(DOMPointReadOnly.prototype, "toJSON", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, DOMPointReadOnly.prototype, "DOMPointReadOnly", "toJSON", arguments)}});
