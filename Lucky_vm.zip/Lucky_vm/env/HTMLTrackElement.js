// HTMLTrackElement 对象 
HTMLTrackElement = function HTMLTrackElement(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(HTMLTrackElement,"HTMLTrackElement");
Object.setPrototypeOf(HTMLTrackElement.prototype, HTMLElement.prototype);
framevm.toolsFunc.defineProperty(HTMLTrackElement, "NONE", {configurable:false, enumerable:true, writable:false, value:0});
framevm.toolsFunc.defineProperty(HTMLTrackElement, "LOADING", {configurable:false, enumerable:true, writable:false, value:1});
framevm.toolsFunc.defineProperty(HTMLTrackElement, "LOADED", {configurable:false, enumerable:true, writable:false, value:2});
framevm.toolsFunc.defineProperty(HTMLTrackElement, "ERROR", {configurable:false, enumerable:true, writable:false, value:3});
framevm.toolsFunc.defineProperty(HTMLTrackElement.prototype, "kind", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLTrackElement.prototype, "HTMLTrackElement", "kind_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLTrackElement.prototype, "HTMLTrackElement", "kind_set", arguments)}});
framevm.toolsFunc.defineProperty(HTMLTrackElement.prototype, "src", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLTrackElement.prototype, "HTMLTrackElement", "src_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLTrackElement.prototype, "HTMLTrackElement", "src_set", arguments)}});
framevm.toolsFunc.defineProperty(HTMLTrackElement.prototype, "srclang", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLTrackElement.prototype, "HTMLTrackElement", "srclang_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLTrackElement.prototype, "HTMLTrackElement", "srclang_set", arguments)}});
framevm.toolsFunc.defineProperty(HTMLTrackElement.prototype, "label", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLTrackElement.prototype, "HTMLTrackElement", "label_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLTrackElement.prototype, "HTMLTrackElement", "label_set", arguments)}});
framevm.toolsFunc.defineProperty(HTMLTrackElement.prototype, "default", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLTrackElement.prototype, "HTMLTrackElement", "default_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLTrackElement.prototype, "HTMLTrackElement", "default_set", arguments)}});
framevm.toolsFunc.defineProperty(HTMLTrackElement.prototype, "readyState", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLTrackElement.prototype, "HTMLTrackElement", "readyState_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(HTMLTrackElement.prototype, "track", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLTrackElement.prototype, "HTMLTrackElement", "track_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(HTMLTrackElement.prototype, "NONE", {configurable:false, enumerable:true, writable:false, value:0});
framevm.toolsFunc.defineProperty(HTMLTrackElement.prototype, "LOADING", {configurable:false, enumerable:true, writable:false, value:1});
framevm.toolsFunc.defineProperty(HTMLTrackElement.prototype, "LOADED", {configurable:false, enumerable:true, writable:false, value:2});
framevm.toolsFunc.defineProperty(HTMLTrackElement.prototype, "ERROR", {configurable:false, enumerable:true, writable:false, value:3});
