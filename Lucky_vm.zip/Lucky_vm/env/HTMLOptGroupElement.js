// HTMLOptGroupElement 对象
HTMLOptGroupElement = function HTMLOptGroupElement(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(HTMLOptGroupElement,"HTMLOptGroupElement");
Object.setPrototypeOf(HTMLOptGroupElement.prototype, HTMLElement.prototype);
framevm.toolsFunc.defineProperty(HTMLOptGroupElement.prototype, "disabled", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLOptGroupElement.prototype, "HTMLOptGroupElement", "disabled_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLOptGroupElement.prototype, "HTMLOptGroupElement", "disabled_set", arguments)}});
framevm.toolsFunc.defineProperty(HTMLOptGroupElement.prototype, "label", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, HTMLOptGroupElement.prototype, "HTMLOptGroupElement", "label_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, HTMLOptGroupElement.prototype, "HTMLOptGroupElement", "label_set", arguments)}});
