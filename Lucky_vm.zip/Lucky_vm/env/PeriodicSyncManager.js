// PeriodicSyncManager 对象 
PeriodicSyncManager = function PeriodicSyncManager(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(PeriodicSyncManager,"PeriodicSyncManager");
framevm.toolsFunc.defineProperty(PeriodicSyncManager.prototype, "getTags", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, PeriodicSyncManager.prototype, "PeriodicSyncManager", "getTags", arguments)}});
framevm.toolsFunc.defineProperty(PeriodicSyncManager.prototype, "register", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, PeriodicSyncManager.prototype, "PeriodicSyncManager", "register", arguments)}});
framevm.toolsFunc.defineProperty(PeriodicSyncManager.prototype, "unregister", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, PeriodicSyncManager.prototype, "PeriodicSyncManager", "unregister", arguments)}});
