// MIDIOutputMap 对象 
MIDIOutputMap = function MIDIOutputMap(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(MIDIOutputMap,"MIDIOutputMap");
framevm.toolsFunc.defineProperty(MIDIOutputMap.prototype, "size", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, MIDIOutputMap.prototype, "MIDIOutputMap", "size_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(MIDIOutputMap.prototype, "entries", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MIDIOutputMap.prototype, "MIDIOutputMap", "entries", arguments)}});
framevm.toolsFunc.defineProperty(MIDIOutputMap.prototype, "forEach", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MIDIOutputMap.prototype, "MIDIOutputMap", "forEach", arguments)}});
framevm.toolsFunc.defineProperty(MIDIOutputMap.prototype, "get", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MIDIOutputMap.prototype, "MIDIOutputMap", "get", arguments)}});
framevm.toolsFunc.defineProperty(MIDIOutputMap.prototype, "has", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MIDIOutputMap.prototype, "MIDIOutputMap", "has", arguments)}});
framevm.toolsFunc.defineProperty(MIDIOutputMap.prototype, "keys", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MIDIOutputMap.prototype, "MIDIOutputMap", "keys", arguments)}});
framevm.toolsFunc.defineProperty(MIDIOutputMap.prototype, "values", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, MIDIOutputMap.prototype, "MIDIOutputMap", "values", arguments)}});
