// ResizeObserver 对象 
ResizeObserver = function ResizeObserver(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'ResizeObserver': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(ResizeObserver,"ResizeObserver");
framevm.toolsFunc.defineProperty(ResizeObserver.prototype, "disconnect", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, ResizeObserver.prototype, "ResizeObserver", "disconnect", arguments)}});
framevm.toolsFunc.defineProperty(ResizeObserver.prototype, "observe", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, ResizeObserver.prototype, "ResizeObserver", "observe", arguments)}});
framevm.toolsFunc.defineProperty(ResizeObserver.prototype, "unobserve", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, ResizeObserver.prototype, "ResizeObserver", "unobserve", arguments)}});
