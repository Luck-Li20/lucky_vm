// CSSTransformComponent 对象 
CSSTransformComponent = function CSSTransformComponent(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(CSSTransformComponent,"CSSTransformComponent");
framevm.toolsFunc.defineProperty(CSSTransformComponent.prototype, "is2D", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, CSSTransformComponent.prototype, "CSSTransformComponent", "is2D_get", arguments)}, set:function (){return framevm.toolsFunc.dispatch(this, CSSTransformComponent.prototype, "CSSTransformComponent", "is2D_set", arguments)}});
framevm.toolsFunc.defineProperty(CSSTransformComponent.prototype, "toMatrix", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSTransformComponent.prototype, "CSSTransformComponent", "toMatrix", arguments)}});
framevm.toolsFunc.defineProperty(CSSTransformComponent.prototype, "toString", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, CSSTransformComponent.prototype, "CSSTransformComponent", "toString", arguments)}});
