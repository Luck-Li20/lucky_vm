// HTMLUnknownElement 对象
HTMLUnknownElement = function HTMLUnknownElement(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(HTMLUnknownElement,"HTMLUnknownElement");
Object.setPrototypeOf(HTMLUnknownElement.prototype, HTMLElement.prototype);
