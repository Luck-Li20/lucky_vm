// Geolocation 对象
Geolocation = function Geolocation(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(Geolocation,"Geolocation");
framevm.toolsFunc.defineProperty(Geolocation.prototype, "clearWatch", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Geolocation.prototype, "Geolocation", "clearWatch", arguments)}});
framevm.toolsFunc.defineProperty(Geolocation.prototype, "getCurrentPosition", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Geolocation.prototype, "Geolocation", "getCurrentPosition", arguments)}});
framevm.toolsFunc.defineProperty(Geolocation.prototype, "watchPosition", {configurable:true, enumerable:true, writable:true, value:function (){return framevm.toolsFunc.dispatch(this, Geolocation.prototype, "Geolocation", "watchPosition", arguments)}});
