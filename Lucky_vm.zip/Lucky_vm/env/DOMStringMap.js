// DOMStringMap 对象 
DOMStringMap = function DOMStringMap(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(DOMStringMap,"DOMStringMap");
