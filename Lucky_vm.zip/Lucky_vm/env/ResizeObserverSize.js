// ResizeObserverSize 对象 
ResizeObserverSize = function ResizeObserverSize(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(ResizeObserverSize,"ResizeObserverSize");
framevm.toolsFunc.defineProperty(ResizeObserverSize.prototype, "inlineSize", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, ResizeObserverSize.prototype, "ResizeObserverSize", "inlineSize_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(ResizeObserverSize.prototype, "blockSize", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, ResizeObserverSize.prototype, "ResizeObserverSize", "blockSize_get", arguments)}, set:undefined});
