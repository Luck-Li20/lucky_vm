// GravitySensor 对象 
GravitySensor = function GravitySensor(){};
framevm.toolsFunc.safeProto(GravitySensor,"GravitySensor");
Object.setPrototypeOf(GravitySensor.prototype, Accelerometer.prototype);
