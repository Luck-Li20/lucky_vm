// AbsoluteOrientationSensor 对象 
AbsoluteOrientationSensor = function AbsoluteOrientationSensor(){};
framevm.toolsFunc.safeProto(AbsoluteOrientationSensor,"AbsoluteOrientationSensor");
Object.setPrototypeOf(AbsoluteOrientationSensor.prototype, OrientationSensor.prototype);
