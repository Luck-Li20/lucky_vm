// AudioWorklet 对象 
AudioWorklet = function AudioWorklet(){return framevm.toolsFunc.throwError("TypeError", "Illegal constructor");};
framevm.toolsFunc.safeProto(AudioWorklet,"AudioWorklet");
Object.setPrototypeOf(AudioWorklet.prototype, Worklet.prototype);
