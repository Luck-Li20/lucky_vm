// DecompressionStream 对象 
DecompressionStream = function DecompressionStream(){return framevm.toolsFunc.throwError("TypeError", "Failed to construct 'DecompressionStream': 1 argument required, but only 0 present.");};
framevm.toolsFunc.safeProto(DecompressionStream,"DecompressionStream");
framevm.toolsFunc.defineProperty(DecompressionStream.prototype, "readable", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DecompressionStream.prototype, "DecompressionStream", "readable_get", arguments)}, set:undefined});
framevm.toolsFunc.defineProperty(DecompressionStream.prototype, "writable", {configurable:true, enumerable:true, get:function (){return framevm.toolsFunc.dispatch(this, DecompressionStream.prototype, "DecompressionStream", "writable_get", arguments)}, set:undefined});
